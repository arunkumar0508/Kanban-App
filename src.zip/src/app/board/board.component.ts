import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProjectService } from '../../services/project.service';
import { board } from '../models/board';

@Component({
  selector: 'app-board',
  templateUrl: './board.component.html',
  styleUrls: ['./board.component.css']
})
export class BoardComponent implements OnInit {
  projectId: string | undefined;
  board: board | undefined;
  newTaskTitle: string = '';
  newTaskDescription: string = '';
  newTaskAssigningName: string = '';
  isFormOpen: boolean = false;
  openTaskDetailsModal: boolean = false;
  selectedTask: any;
  newTaskStatus: string = '';
  targetColumn: string = '';

  constructor(
    private route: ActivatedRoute,
    private projectService: ProjectService
  ) {
    this.board = {
      boardId: null,
      name: '',
      columns: []
    };
  }

  ngOnInit(): void {
    this.route.params.subscribe((params) => {
      console.log('Route Params:', params);
      this.projectId = String(params['id']) ?? undefined;
      console.log('Extracted projectId:', this.projectId);

      if (!this.projectId) {
        console.error('projectId is undefined or null.');
      } else {
        this.loadBoardDetails();
      }
    });
  }

  loadBoardDetails() {
    if (this.projectId) {
      const email = localStorage.getItem('userEmail');

      if (email) {
        this.projectService.getProjectDetails(email, this.projectId).subscribe(
          (response) => {
            this.board = response.board;
            console.log(this.board);
          },
          (error) => {
            console.error('Error loading board details:', error);
          }
        );
      } else {
        console.error('User email is missing.');
      }
    }
  }

  openAddTaskForm() {
    this.isFormOpen = true;
  }

  closeAddTaskForm() {
    this.isFormOpen = false;
    this.resetFormFields();
  }

  addTask() {
    if (this.newTaskTitle.trim() !== '') {
      const newTask = {
        title: this.newTaskTitle,
        description: this.newTaskDescription,
        assigningName: this.newTaskAssigningName,
        status: ''
      };

      if (this.projectId) {
        this.projectService.createTaskInFirstColumn(this.projectId, newTask).subscribe(
          (response) => {
            if (this.board && this.board.columns[0]) {
              this.board.columns[0].tasks.push(response.task);
              this.closeAddTaskForm();
              this.resetFormFields();
            }
          },
          (error) => {
            console.error('Error creating a task:', error);
          }
        );
      }
    }
  }

  resetFormFields() {
    this.newTaskTitle = '';
    this.newTaskDescription = '';
    this.newTaskAssigningName = '';
  }

  showTaskDetails(task: any) {
    this.selectedTask = task;
    this.openTaskDetailsModal = true;
  }

  hideTaskDetails() {
    this.selectedTask = null;
    this.openTaskDetailsModal = false;
  }

  // Function to update task status and move it to the corresponding column
  updateTaskStatusAndMove(task: any, newStatus: string, targetColumn: string) {
    if (task.status === newStatus) {
      // No need to update if the status remains the same
      return;
    }

    // Find the target column based on the newStatus
    const targetColumnObj = this.board?.columns.find((column) => column.name === newStatus);

    if (targetColumnObj) {
      // Remove the task from the current column
      const currentColumn = this.board?.columns.find((column) => column.tasks.includes(task));

      if (currentColumn && currentColumn.tasks) {
        currentColumn.tasks = currentColumn.tasks.filter((t) => t !== task);
      }

      // Add the task to the target column
      targetColumnObj.tasks.push(task);

      // Update the task's status
      task.status = newStatus;

      // Call the updateTask method with targetColumn parameter
      if (this.projectId) {
        this.projectService.updateTask(this.projectId, task, targetColumn).subscribe(
          (response) => {
            console.log('Task successfully updated in the database:', response);
          },
          (error) => {
            console.error('Error updating task in the database:', error);
          }
        );
      }
    }
  }
}
