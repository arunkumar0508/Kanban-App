export type task={
    title: string;
    description:string;
    assigningname:string;
    status:string;
}