export type task={
    title: string;
    description:string;
    assigningName:string;
    status:string;
}