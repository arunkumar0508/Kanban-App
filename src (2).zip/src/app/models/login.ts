export interface LoginResponse {
    token: string;
    message: string;
  }